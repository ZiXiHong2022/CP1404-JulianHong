import random
print(random.randint(5,20))
print(random.randrange(3,10,2))
print(random.uniform(2.5,5.5))


'''
line 1 
the largest is 19
line 2
the smallest is 3 , largest is 8
it couldn't produce 4 
line 3
the smallest number is 2.5
the smallest number is 5.4

'''

print(random.randint(0,100))