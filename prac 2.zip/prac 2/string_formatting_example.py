#part1
name = 'Gibson L-5 CES '
year = 1922
money = 16035
print("{}{} for about $ {}".format(year,name,money))
#part2
for i in range(0,151,50):
    print(f"{i}")


